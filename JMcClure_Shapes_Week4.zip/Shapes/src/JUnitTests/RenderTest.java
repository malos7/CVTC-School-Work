package JUnitTests;
import org.junit.Test;

import shapes.Cuboid;
import shapes.Cylinder;
import shapes.Sphere;

import static org.junit.Assert.*;
public class RenderTest {

	
	@Test
	MessageBoxSub box11 = new MessageBoxSub();
	
	Cuboid cuboid1 = new Cuboid(box11, 1, 1, 1);
	Cylinder cylinder1 = new Cylinder (box11, 1, 1);
	Sphere sphere1 = new Sphere (box11, 1);
	
	cuboid1.render();
	cylinder1.render();
	sphere1.render();
}
