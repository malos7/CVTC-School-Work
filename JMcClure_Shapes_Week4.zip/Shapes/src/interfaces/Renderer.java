package interfaces;

public interface Renderer {

	public void render();
	
}
