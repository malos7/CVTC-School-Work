package shapesTest;

import static org.junit.Assert.*;

import org.junit.Test;

import shapes.Sphere;

public class SphereTest {

	Sphere sphere1 = new Sphere(1);
	Sphere sphere2 = new Sphere(2);

	
	@Test
	public void testConstructor() {
		assertTrue(sphere1 instanceof Sphere);
	}
	
	@Test
	public void testGetRadius() {
		assertEquals(1.0, sphere1.getRadius(), 0.0);
	}
	
	@Test
	public void testVolume() {
		assertEquals(3.14, sphere1.volume(), 0.01);
		assertEquals(25.13, sphere2.volume(), 0.01);

	}
	
	@Test
	public void testSurfaceArea() {
		assertEquals(12.566, sphere1.surfaceArea(), 0.01);
		assertEquals(50.26, sphere2.surfaceArea(), 0.01);
;
	}

}
