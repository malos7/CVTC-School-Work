package shapesTest;

import static org.junit.Assert.*;

import org.junit.Test;

import shapes.Cylinder;

public class CylinderTest {

	
	Cylinder cylinder1 = new Cylinder(1, 1);
	Cylinder cylinder2 = new Cylinder(2, 2);

	
	@Test
	public void testConstructor() {
		assertTrue(cylinder1 instanceof Cylinder);
	}
	
	@Test
	public void testGetRadius() {
		assertEquals(1.0, cylinder1.getRadius(), 0.0);
	}
	
	@Test
	public void testGetHeight() {
		assertEquals(1.0, cylinder1.getHeight(), 0.0);
	}
	
	@Test
	public void testVolume() {
		assertEquals(3.14, cylinder1.volume(), 0.01);
		assertEquals(25.13, cylinder2.volume(), 0.01);

	}
	
	@Test
	public void testSurfaceArea() {
		assertEquals(12.56, cylinder1.surfaceArea(), 0.01);
		assertEquals(50.26, cylinder2.surfaceArea(), 0.01);

	}

}
