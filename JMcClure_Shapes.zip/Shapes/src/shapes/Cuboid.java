/**
 * 
 */
package shapes;

import javax.swing.JOptionPane;

/**
 * @author Jordan
 *
 */
public class Cuboid extends Shapes {

	// Variables
	private float width = 0.0f;
	private float height = 0.0f;
	private float depth = 0.0f;
	
	// get and set
	
	public float getWidth() {
		return width;
	}
	public void setWidth(float width) {
		this.width = width;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	public float getDepth() {
		return depth;
	}
	public void setDepth(float depth) {
		this.depth = depth;
	}
	
	
	// Inherited methods
	@Override
	public float surfaceArea() {
		// return surface area of cuboid
		return 2 * height * (width + depth);
	}
	@Override
	public float volume() {
		// return volume of cuboid
		return (height * width * depth);
	}
	@Override
	public void render() {
		//message displays dimensions, surface area, volume
		JOptionPane.showMessageDialog(null, "Cuboid\n" + "Height " + this.height + "\n Width " + this.width 
										+ "\n Depth " + this.depth + "\n Surface Area " + this.surfaceArea() + "\n Volume " + this.volume());
	}

	
	// Constructor
	public Cuboid(float width, float height, float depth) {
		this.width = width;
		this.height = height;
		this.depth = depth;
	}

	
}
