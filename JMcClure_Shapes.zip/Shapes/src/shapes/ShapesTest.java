
package shapes;

import java.util.Scanner;
import java.util.InputMismatchException;
public class ShapesTest {
	
	public static void main(String args[]) {
	
		//set variables
		float height = 0;
		float depth = 0;
		float radius = 0;
		float width = 0;
		double choice;
		
		
		//keyboard scanner
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Please follow the promts: \n");
		System.out.print("1. Calculate the Area of a Cuboid\n");
	    System.out.print("2. Calculate the Area of a Cylinder\n");
	    System.out.print("3. Calculate the Area of a Sphere\n");
	    System.out.print("4. Quit\n");
	    System.out.print("Enter your choice (1-4):");
	    choice = keyboard.nextDouble();
	    
	    //Validate input choice is between 1 - 4
	    while (choice < 1 || choice > 4) {
	        System.out.print("That is not an option\n");
	        System.out.print("Please follow the promts:");
			System.out.print("1. Calculate the Area of a Cuboid\n");
		    System.out.print("2. Calculate the Area of a Cylinder\n");
		    System.out.print("3. Calculate the Area of a Sphere\n");
		    System.out.print("4. Quit\n");
		    System.out.print("Enter your choice (1-4):");
	        choice = keyboard.nextDouble();
	      }
	    
	    if(choice == 1) {
	    	try{
		    	System.out.print("What is the Height of your Cuboid?");
	            height = keyboard.nextFloat();
	            System.out.print("What is the Depth of your Cuboid?");
	            depth = keyboard.nextFloat();
	            System.out.print("What is the Width of your Cuboid?");
	            width = keyboard.nextFloat();
	            
	            while(depth < 0 || height < 0 || width < 0) {
		    		System.out.print("You cannont use a negative number try again.\n");
		          	System.out.print("What is the Depth of your Cuboid?");
		          	depth = keyboard.nextFloat();
		          	System.out.print("What is the Height of your Cuboid?");
		          	height = keyboard.nextFloat();
		          	System.out.print("What is the Width of your Cuboid?");
		          	width = keyboard.nextFloat();
		    		System.out.print("Please use numbers.");
	            }
            } catch (InputMismatchException e) {
            	System.out.print("Use a number please for the love of all things heavenly! \n");
            	main(null);
            }
	    
        Cuboid cuboid1 = new Cuboid(width, height, depth);
        cuboid1.render();
        main(null);
	    } 
	    else {
	        if(choice == 2) {
	        	try {
		        	System.out.print("What is the Height of your Cylinder?");
		            height = keyboard.nextFloat();
		            System.out.print("What is the Radius of your Cylinder?");
		            radius = keyboard.nextFloat();
		            
		            while(radius < 0 || height < 0) {
			    		System.out.print("You cannont use a negative number try again.\n");
			          	System.out.print("What is the Depth of your Cylinder?");
			          	radius = keyboard.nextFloat();
			          	System.out.print("What is the Height of your Cylinder?");
			          	height = keyboard.nextFloat();
			    		System.out.print("Please use numbers.");
		            }
		        } catch (InputMismatchException e) {
		        	System.out.print("Use a number please for the love of all things heavenly! \n");
		        	main(null);
		        }
		    	Cylinder cylinder1 = new Cylinder(radius, height);
		    	cylinder1.render();
		        main(null);
	        } 
	        else {
	        	if(choice == 3) {
		        	try {
			            System.out.print("What is the Radius of your Sphere?");
			            radius = keyboard.nextFloat();
			            
			            while(radius < 0 || height < 0) {
				    		System.out.print("You cannont use a negative number try again.\n");
				    		System.out.print("What is the Radius of your Sphere?");
				            radius = keyboard.nextFloat();
				    		System.out.print("Please use numbers.");
			            }
		            } catch (InputMismatchException e) {
		            	System.out.print("Use a number please for the love of all things heavenly! \n");
		            	main(null);
		            }
			        Sphere sphere1 = new Sphere(radius);
			    	sphere1.render();
			        main(null);
	        	}
	        	else {
	        		if (choice == 4) {
	        			System.exit(0);
	        		}
	        	}
	        }
	    }
	}
}
