
package shapes;

/**
 * @author Jordan
 *
 */
import shapes.Cuboid;

public class ShapesTest {
	
	public static void main(String args[]) {
		
		Cuboid cuboid = new Cuboid(12f, 13f, 14f);
		cuboid.render();
		
		Cylinder cylinder = new Cylinder(8f, 10f);
		cylinder.render();
		
		Sphere sphere = new Sphere(32f);
		sphere.render();

	}

}
