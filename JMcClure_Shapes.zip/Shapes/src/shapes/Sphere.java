/**
 * 
 */
package shapes;

import javax.swing.JOptionPane;

/**
 * @author Jordan
 *
 */
public class Sphere extends Shapes {

	//Variables
	public float radius = 0.0f;
	private float pi = (float) Math.PI;

	
	//Get and set
	public float getRadius() {
			return radius;	
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	
	//Inherited methods
	@Override
	public float surfaceArea() {
		// return surface area
		return 4 * pi * (float)Math.pow(radius, 2);
	}

	@Override
	public float volume() {
		// return volume
		return (4/3) * pi * (float)Math.pow(radius, 3);
	}

	@Override
	public void render() {
		//message displays dimensions, surface area, volume
		JOptionPane.showMessageDialog(null, "Sphere\n" + "\n radius " + this.radius 
				 + "\n Surface Area " + this.surfaceArea() + "\n Volume " + this.volume());
	}

	
	//Constructor
	public Sphere(float radius) {
		super();
		this.radius = radius;
	}

}
