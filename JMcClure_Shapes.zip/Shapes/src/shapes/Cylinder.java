/**
 * 
 */
package shapes;

import javax.swing.JOptionPane;

/**
 * @author Jordan
 *
 */
public class Cylinder extends Shapes {

	//Variables
	private float radius = 0.0f;
	private float height = 0.0f;
	private float pi = (float) Math.PI; 
	
	
	//get and set
	public float getRadius() {
		return radius;
	}
	public void setRadius(float radius) {
		this.radius = radius;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	
	
	//Inherited methods
	@Override
	public float surfaceArea() {
		// return surface area
		return 2 * (pi * (float)Math.pow(radius, 2)) + (2 * pi * radius) * height ;
	}
	@Override
	public float volume() {
		// return volume
		return pi * (float)Math.pow(radius, 2) * height;
	}
	@Override
	public void render() {
		//message displays dimensions, surface area, volume
		JOptionPane.showMessageDialog(null, "Cylinder\n" + "Height " + this.height + "\n radius " + this.radius 
			 + "\n Surface Area " + this.surfaceArea() + "\n Volume " + this.volume());
}
	
	
	//Constructs
	public Cylinder(float radius, float height) {
		super();
		this.radius = radius;
		this.height = height;
	}

}
