
package shapesTest;

import enumerator.ShapeType;
import interfaces.Dialog;
import shapes.MessageBox;
import shapes.ShapeFactory;
import shapes.Shapes;

public class ShapesTest {

	public static void main(String[] args) {
		
		Dialog dialog = new MessageBox();
		
		ShapeFactory shapeFactory = new ShapeFactory(null);

		Shapes cuboid1 = shapeFactory.make(ShapeType.Cuboid);
		cuboid1.render();
		Shapes cylinder1 = shapeFactory.make(ShapeType.Cylinder);
		cylinder1.render();
		Shapes shpere1 = shapeFactory.make(ShapeType.Sphere);
		shpere1.render();	
	}
}