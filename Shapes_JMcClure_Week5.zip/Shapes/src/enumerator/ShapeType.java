package enumerator;
public enum ShapeType {
	
	Cuboid, Cylinder, Sphere;
	
}
