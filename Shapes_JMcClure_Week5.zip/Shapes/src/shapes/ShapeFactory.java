package shapes;

import enumerator.ShapeType;
import interfaces.Dialog;
import interfaces.Renderer;

public class ShapeFactory  {

	private Dialog dialog;
	
	public ShapeFactory(Dialog dialog) {
		this.dialog = dialog;
	}
	
	public Shapes make(ShapeType type) {
		if(type == null) {
			return null;
		}else if(type == ShapeType.Cuboid) {
			return new Cuboid(dialog, 1, 1, 1);
		}else if(type == ShapeType.Sphere) {
			return new Sphere(dialog, 1);
		}else if(type == ShapeType.Cylinder) {
			return new Cylinder(dialog, 1, 1);
		}
		return null;
	}
	
	
}
