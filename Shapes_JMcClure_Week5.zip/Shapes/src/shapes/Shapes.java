/**
 * 
 */
package shapes;

import interfaces.Dialog;

/**
 * @author Jordan
 *
 */
public abstract class Shapes implements Dialog {
	
	private Dialog messageBox;
	
	protected Dialog getMessageBox() {
		return this.messageBox;
	}
	
	public void setMessageBox(Dialog messageBox) {
		this.messageBox = messageBox;
	}
	
	public Shapes(Dialog messageBox) {
		super();
		this.messageBox = messageBox;
	}
	
	public abstract float surfaceArea();
	
	public abstract float volume();
	
	public void render() {
		
	}

}
