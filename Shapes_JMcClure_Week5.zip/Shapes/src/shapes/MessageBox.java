package shapes;

import javax.swing.JOptionPane;

import interfaces.Dialog;

public class MessageBox implements Dialog {

	
	@Override
	public int show(String title, String message) {

		JOptionPane.showMessageDialog(null, message);
		
		return JOptionPane.OK_OPTION;
	}	
}
