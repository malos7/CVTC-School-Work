package JUnitTests;

import interfaces.Dialog;

public class MessageBoxSub {

	public static int messageBoxSub() {
		return 0x00;
	}
	
}
