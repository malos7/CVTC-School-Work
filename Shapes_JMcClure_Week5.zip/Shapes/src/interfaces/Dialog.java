package interfaces;

public interface Dialog {

	public int show(String title, String message);
	
}
