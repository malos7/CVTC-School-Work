package JUnitTests;

import static org.junit.Assert.*;

import shapes.Cuboid;
import org.junit.Test;

public class CuboidTest {

	
	Cuboid cube1 = new Cuboid(null, 1, 1, 1);
	Cuboid cube2 = new Cuboid(null, 2, 2, 2);

	
	@Test
	public void testConstructor() {
		assertTrue(cube1 instanceof Cuboid);
	}

	@Test
	public void testGetWidth() {
		assertEquals(1.0, cube1.getWidth(), 0.0);
	}
	
	@Test
	public void testGetHeight() {
		assertEquals(1.0, cube1.getHeight(), 0.0);
	}
	
	@Test
	public void testGetDepth() {
			assertEquals(1.0, cube1.getDepth(), 0.0);
	}
	
	@Test
	public void testVolume() {
			assertEquals(1.0, cube1.volume(), 0.0);
			assertEquals(8.0, cube2.volume(), 0.0);
	}
	
	@Test
	public void testSurfaceArea() {
			assertEquals(4.0, cube1.surfaceArea(), 0.0);
			assertEquals(16.0, cube2.surfaceArea(), 0.0);
			
	}
}
