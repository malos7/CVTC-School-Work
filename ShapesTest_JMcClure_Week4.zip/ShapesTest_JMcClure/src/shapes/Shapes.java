/**
 * 
 */
package shapes;

import interfaces.Dialog;

/**
 * @author Jordan
 *
 */
public abstract class Shapes implements Dialog {
	
	private MessageBoxSub messageBox;
	
	protected Dialog getMessageBox() {
		return this.messageBox;
	}
	
	public void setMessageBox(MessageBoxSub messageBox) {
		this.messageBox = messageBox;
	}
	
	public Shapes(MessageBoxSub box11) {
		super();
		this.messageBox = box11;
	}
	
	public abstract float surfaceArea();
	
	public abstract float volume();

}
